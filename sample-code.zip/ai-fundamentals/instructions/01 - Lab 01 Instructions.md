# AI-900 Labs
## 01 - Lab 01 Instructions
In this lab we will be looking at guidelines for Responsible AI.

### Tasks
1.	Go to [Guidelines for Human-AI Interaction demo](https://aka.ms/hci-demo)
2.	Pick cards from each deck and review the example scenarios
3.	Identify the Responsible AI principle(s) that the examples represent
