# AI-900 Labs
## 05 - Lab 05 Instructions
In this lab we will create a bot that answers user questions.

### Tasks
1.	Start Visual Studio Code and open the ai-fundamentals project.
2.	Open the **03a - QnA Bot.ipynb** notebook.
3.	Follow the instructions in the notebook to complete the lab.
